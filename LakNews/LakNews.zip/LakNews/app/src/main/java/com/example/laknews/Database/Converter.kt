package com.example.laknews.Database

import androidx.room.TypeConverter
import com.example.laknews.Models.Source

class Converter {

    @TypeConverter
    fun sourceToString(source: Source): String{
        return source.name
    }

    @TypeConverter
    fun stringToSource(string: String) : Source {
        return Source(string,string)
    }
}