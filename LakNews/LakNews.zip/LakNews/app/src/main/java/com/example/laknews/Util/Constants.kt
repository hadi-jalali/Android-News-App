package com.example.laknews.Util

class Constants {
    companion object{
        const val API_KEY="77ac43b05668445599e04e725c8ad8b8"
        const val BASE_URL="https://newsapi.org"
        const val QUERY_PAGE_SIZE=20


    }
}