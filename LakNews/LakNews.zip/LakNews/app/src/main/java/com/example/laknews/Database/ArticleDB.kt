package com.example.laknews.Database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.laknews.Models.Article

@Database(
    entities = [Article::class],
    version = 1
)

@TypeConverters(Converter::class)
abstract class ArticleDB : RoomDatabase(){

    abstract fun articleDao():ArticleDao

    companion object {
        @Volatile
        private var instance:ArticleDB?=null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance?: synchronized(LOCK){
            instance?:createDB(context).also{ instance=it}
        }

        private fun createDB(context: Context) = Room.databaseBuilder(context.applicationContext,ArticleDB::class.java
            ,"articleDB").build()

    }
}