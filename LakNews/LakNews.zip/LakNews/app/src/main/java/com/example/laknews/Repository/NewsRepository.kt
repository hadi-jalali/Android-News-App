package com.example.laknews.Repository

import android.app.DownloadManager
import com.example.laknews.Api.RetrofitInstance
import com.example.laknews.Models.Article
import com.example.laknews.Database.ArticleDB

class NewsRepository (val db : ArticleDB) {

    suspend fun getBreakingNews(countryCode: String, pagenumber:Int) = RetrofitInstance.
    api.getBreakingNews(countryCode,pagenumber)

    suspend fun searchNews(searchQuery: String, pagenumber:Int) = RetrofitInstance.
    api.searchForNews(searchQuery,pagenumber)

    suspend fun getAllNews(q: String, pagenumber: Int) = RetrofitInstance.
    api.getAllNews(q,pagenumber)

    suspend fun updateAndInsert(article: Article) = db.articleDao().updateAndInsert(article)

    fun getSavedNews() = db.articleDao().getAllArticle()

    suspend fun deleteArticle(article: Article) = db.articleDao().deleteArticle(article)

}