package com.example.laknews.UI

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.laknews.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.signup_layout.*
import java.util.*
import kotlin.collections.HashMap


class SignupActivity: AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    val TAG = "SignupActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup_layout)
        auth = FirebaseAuth.getInstance()
        next_btn.setOnClickListener {
            signupUser()
        }
    }

    private fun signupUser(){
            if(signupEmail.text.toString().isEmpty()){
                signupEmail.error = "Please enter email"
                signupEmail.requestFocus()
                return
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(signupEmail.text.toString()).matches()){
                signupEmail.error = "Please enter a valid email"
                signupEmail.requestFocus()
                return
            }
            if (signup_password.text.toString().isEmpty()){
                signup_password.error = "Please enter your password"
                signup_password.requestFocus()
                return
            }

        auth.createUserWithEmailAndPassword(signupEmail.text.toString(), signup_password.text.toString())
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        val user = Firebase.auth.currentUser
                        val firestoreDB = FirebaseFirestore.getInstance()
                        val user1 = hashMapOf("preference" to preferences.text.toString() , "email" to signupEmail.text.toString() )

                        firestoreDB.collection("users")
                            .add(user1)
                            .addOnSuccessListener { documentReference ->
                                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                            }
                        user?.sendEmailVerification()
                                ?.addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        startActivity(Intent(this, LoginActivity::class.java))
                                        finish()
                                    }
                                }
                    } else {
                Toast.makeText(baseContext, "Sign up failed",
                        Toast.LENGTH_SHORT).show()
            }
        }

    }


    private fun saveToFirestore(preference: String) {
        val firestoreDB = FirebaseFirestore.getInstance()
        val user = hashMapOf("preference" to preference)

        firestoreDB.collection("users")
            .add(user)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error adding document", e)
            }



    }


}
