package com.example.laknews.Fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.laknews.Adapters.NewsAdapter
import com.example.laknews.UI.NewsActivity
import com.example.laknews.Util.Resource
import android.util.Log;
import android.widget.AbsListView
import androidx.core.widget.addTextChangedListener
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.laknews.UI.NewsViewModel
import com.example.laknews.Util.Constants
import com.example.laknews.R
import kotlinx.android.synthetic.main.fragment_breaking_news.*
import kotlinx.android.synthetic.main.fragment_recent_news.*
import kotlinx.android.synthetic.main.fragment_recent_news.paginationProgressBar
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RecentNewsFragment:Fragment(R.layout.fragment_recent_news) {

    lateinit var viewModel: NewsViewModel
    lateinit var newsAdapter: NewsAdapter
    val TAG = "RecentNewsFragment"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = (activity as NewsActivity).viewModel
        setupRecyclerView()

        newsAdapter.setOnItemClickListener {
            val bundle = Bundle().apply {
                putSerializable("article", it)
            }
            findNavController().navigate(
                R.id.action_recentNewsFragment_to_articleFragment,
                bundle
            )
        }

        viewModel.allNews.observe(viewLifecycleOwner, Observer { response ->
            when (response) {
                is Resource.Success -> {
                    hideProgressBar()
                    response.data?.let { newsResponse ->
                        newsAdapter.differ.submitList(newsResponse.articles.toList())
                        val totalPages = (newsResponse.totalResults / Constants.QUERY_PAGE_SIZE) + 2
                        islastPage = viewModel.allNewsPage == totalPages

                        if(islastPage){
                            rvRecentNews.setPadding(0,0,0,0)
                        }
                    }
                }
                is Resource.Error -> {
                    hideProgressBar()
                    response.message?.let { message ->
                        Log.e(TAG, "An error occurred: $message ")
                    }
                }
                is Resource.Loading -> {
                    showProgressBar()
                }
            }

        })
    }

    private fun hideProgressBar() {
        paginationProgressBar.visibility = View.INVISIBLE
        isloading = false
    }

    private fun showProgressBar() {
        paginationProgressBar.visibility = View.VISIBLE
        isloading = true
    }

    var isloading = false
    var islastPage = false
    var isScrolling = false

    val scrollListener = object : RecyclerView.OnScrollListener(){
        override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
            super.onScrollStateChanged(recyclerView, newState)
            if(newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL){
                isScrolling = true
            }
        }

        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            super.onScrolled(recyclerView, dx, dy)

            val layoutManager = recyclerView.layoutManager as LinearLayoutManager
            val firstItemPos = layoutManager.findFirstVisibleItemPosition()
            val visibleItemCount = layoutManager.childCount
            val totalItemCount = layoutManager.itemCount

            val isNotLoadingNotLastPage = !isloading && !islastPage
            val isLast = firstItemPos +visibleItemCount >= totalItemCount
            val isNotBegging = firstItemPos >=0
            val isTotalMoreThanVisible =  totalItemCount >= Constants.QUERY_PAGE_SIZE
            val shouldPaginate = isNotLoadingNotLastPage &&
                    isLast && isTotalMoreThanVisible && isScrolling

            if(shouldPaginate){
                viewModel.getAllNews("football")
                isScrolling = false
            }
        }
    }

    private fun setupRecyclerView(){
        newsAdapter= NewsAdapter()
        rvRecentNews.apply {
            adapter = newsAdapter
            layoutManager = LinearLayoutManager(activity)
            addOnScrollListener(this@RecentNewsFragment.scrollListener)
        }
    }
}
