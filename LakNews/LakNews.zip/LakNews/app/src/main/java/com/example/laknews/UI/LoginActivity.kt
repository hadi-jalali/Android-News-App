package com.example.laknews.UI

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.laknews.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.login_layout.*

class LoginActivity: AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_layout)
        auth = Firebase.auth
        signup_button.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
            finish()
        }
        login_button.setOnClickListener {
            loginUser()
        }


    }

    private fun loginUser() {
        if (loginEmail.text.toString().isEmpty()) {
            loginEmail.error = "Please enter email"
            loginEmail.requestFocus()
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(loginEmail.text.toString()).matches()) {
            loginEmail.error = "Please enter a valid email"
            loginEmail.requestFocus()
            return
        }
        if (login_password.text.toString().isEmpty()) {
            login_password.error = "Please enter your password"
            login_password.requestFocus()
            return
        }
        auth.signInWithEmailAndPassword(loginEmail.text.toString(), login_password.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    Toast.makeText(
                        baseContext, "Login failed.",
                        Toast.LENGTH_SHORT
                    ).show()
                    updateUI(null)
                }

            }
    }

    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }

    private fun updateUI(currentUser: FirebaseUser?) {
        if (currentUser != null) {
            //if (currentUser.isEmailVerified){
                startActivity(Intent(this, NewsActivity::class.java))
                finish()
           // }
        //else{
         //       Toast.makeText(
         //           baseContext, "Please verify your email first.",
           //         Toast.LENGTH_SHORT
            //    ).show()
            }
     //   }
           else {
            Toast.makeText(
                baseContext, "Login failed.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}