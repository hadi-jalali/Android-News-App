package com.example.laknews.UI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.laknews.R
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.laknews.Repository.NewsRepository
import com.example.laknews.Database.ArticleDB
import kotlinx.android.synthetic.main.activity_news.*

class NewsActivity : AppCompatActivity() {
    lateinit var viewModel: NewsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)


        bottomNavigationView.setupWithNavController(newsNavFragment.findNavController())

        val repository =NewsRepository(ArticleDB(this))
        val viewModelProviderFactory = NewsViewModelProviderFactory(repository)
        viewModel = ViewModelProvider(this, viewModelProviderFactory).get(NewsViewModel::class.java)


    }
}
