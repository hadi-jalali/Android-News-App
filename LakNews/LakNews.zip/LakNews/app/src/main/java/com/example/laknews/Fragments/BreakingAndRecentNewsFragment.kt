package com.example.laknews.Fragments

import android.os.Bundle
import android.widget.TableLayout
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import com.example.laknews.R
import com.google.android.material.tabs.TabLayout

class  BreakingAndRecentNewsFragment: Fragment(R.layout.breaking_and_recent_news) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        //val navigationView = findViewById<NavigationView>(R.id.nav_view)
        val actionDrawer = ActionBarDrawerToggle(this,drawerLayout)
        actionDrawer.isDrawerIndicatorEnabled

        drawerLayout.addDrawerListener(actionDrawer)
        actionDrawer.syncState()

        val mToolbar = findViewById<Toolbar>(R.id.main_toolbar) as androidx.appcompat.widget.Toolbar
        setSupportActionBar(mToolbar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val tabLayout=findViewById<TableLayout>(R.id.tab_layout) as TabLayout
        val viewPager = findViewById<ViewPager2>(R.id.pager)
        val tabTitles=resources.getStringArray(R.array.tab_titles)

        viewPager.adapter = TabAdapter(this)
        TabLayoutMediator(tabLayout,viewPager,TabLayoutMediator.TabConfigurationStrategy {tab, position ->
            when(position){
                0 -> tab.text = tabTitles[0]
                1 -> tab.text = tabTitles[1]
            }
        }).attach()
    }

}
}
